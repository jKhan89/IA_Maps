from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

class ESRI(object):
    def __init__(self, driver):
        self.driver = driver

    def zoom_in(self):
                zInBtn = self.driver.find_element_by_class_name("esriSimpleSliderIncrementButton")
                ActionChains(self.driver).click(zInBtn).perform()

    def zoom_out(self):
                zOutBtn = self.driver.find_element_by_class_name("esriSimpleSliderDecrementButton")
                ActionChains(self.driver).click(zOutBtn).perform()
