from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import selenium.webdriver.support.expected_conditions as EC
import selenium.webdriver.support.ui as ui
from selenium.common.exceptions import TimeoutException


class WF_Functions(object):
        def __init__(self, driver):
                self.driver = driver

        def login(self, username, password):
                self.driver.find_element_by_id("SignonUserName").send_keys(username)
                self.driver.find_element_by_id("SignonPassName").send_keys(password)
                self.driver.find_element_by_id("SignonbtnLogin").click()

        def create_folder(self, name, summary):
                content = self.driver.find_element_by_xpath('//*[contains(text(), "Content") and @class=" sort-column"]')
                ActionChains(self.driver).move_to_element_with_offset(content, 20, 3).context_click().perform()
                ActionChains(self.driver).send_keys('\ue015','\ue015').perform()
                ActionChains(self.driver).send_keys(Keys.RIGHT).perform()
                ActionChains(self.driver).send_keys('\ue006').perform()
                self.driver.implicitly_wait(2)
                fold_name = self.driver.find_element_by_xpath('//*[@id="newdesc"]')
                fold_summ = self.driver.find_element_by_xpath('//*[@id="newsummary"]')
                fold_name.send_keys(name)
                fold_summ.send_keys(summary)
                ActionChains(self.driver).move_to_element(fold_summ).click().perform()
                ActionChains(self.driver).send_keys('\ue004').send_keys('\ue006').perform()

        def create_sub_folder(self, parent, name, summary):
                p_folder = self.driver.find_element_by_xpath('//*[contains(text(), "%s") and @class=" sort-column"]' %parent)
                ActionChains(self.driver).move_to_element_with_offset(p_folder, 30, 3).context_click().perform()
                ActionChains(self.driver).send_keys(Keys.DOWN, Keys.RIGHT).perform()
                ActionChains(self.driver).send_keys(Keys.UP, Keys.UP).perform()
                ActionChains(self.driver).send_keys('\ue006').perform()
                #needs code to enter name and summary, then validate

        def launch_chart(self, folder):
                p_folder = self.driver.find_element_by_xpath('//*[contains(text(), "%s") and @class=" sort-column"]' %folder)
                ActionChains(self.driver).move_to_element_with_offset(p_folder, 30, 3).context_click().perform()
                ActionChains(self.driver).send_keys(Keys.DOWN, Keys.RIGHT,Keys.DOWN,Keys.DOWN,Keys.DOWN).perform()
                ActionChains(self.driver).send_keys('\ue006').perform()
                ok_btn = driver.find_element_by_id("btnOK")
                ActionChains(driver).click(ok_btn).perform()

        def select_tab(name):
                tab_lower = name.lower()
                tab_name = tab_lower.Title()
                tab_id = self.driver.find_element_by_id("%sTab_tabButton" %tab_name)
                ActionChains(self.driver).click(tab_id).perform()

        def select_chart(chart):
                lower_chart = chart.lower()
                chart_name = lower_chart.title()
                if chart_name == "Proportional Symbol":
                        chart_name = "BubbleMap"
                chart_id = driver.find_element_by_id("Format%sChart" %chart_name)
                ActionChains(driver).click(chart_id).perform()

        def is_visible(self, locator, timeout=15):
                try:
                        ui.WebDriverWait(self.driver, timeout).until(EC.visibility_of_element_located((By.CSS_SELECTOR, locator)))
                        return True
                except TimeoutException:
                        return False


        def upload_doc(self, folder):
                p_folder = self.driver.find_element_by_xpath('//*[contains(text(), "%s") and @class=" sort-column"]' %folder)
                ActionChains(self.driver).move_to_element_with_offset(p_folder, 30, 3).context_click().perform()
                ActionChains(self.driver).send_keys(Keys.DOWN,Keys.DOWN,Keys.DOWN,Keys.DOWN,Keys.DOWN,Keys.DOWN,Keys.DOWN,Keys.DOWN,Keys.RIGHT,Keys.DOWN).perform()
                ActionChains(self.driver).send_keys('\ue006').perform()

        def select_file(self, path_to_file):
                dialog = self.driver.find_element_by_css_selector('.bi-component.group-box-container')
                comps = dialog.find_elements_by_css_selector('.bi-component')
                comps[1].send_keys("%s" %path_to_file)
                upld_btn = self.driver.find_element_by_id('btnSubmit')
                self.driver.implicitly_wait(3)
                ActionChains(self.driver).click(upld_btn).perform()
                
        
